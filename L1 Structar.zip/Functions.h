#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>

void convert (std::string& small);
std::string namn_fel(std::string& namn);
std::string city_fel(std::string stad);
int menu();


#endif